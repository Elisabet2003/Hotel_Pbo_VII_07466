package Entity;

public abstract class AbstrackStaff {
    protected String namaStaff;
    protected String idStaff;

    public AbstrackStaff(String namaStaff,String idStaff){
        this.namaStaff = namaStaff;
        this.idStaff = idStaff;
    }

    public String getNamaStaff() {
        return namaStaff;
    }

    public void setNamaStaff(String namaStaff) {
        this.namaStaff = namaStaff;
    }

    public String getIdStaff() {
        return idStaff;
    }

    public void setIdStaff(String idStaff) {
        this.idStaff = idStaff;
    }
}