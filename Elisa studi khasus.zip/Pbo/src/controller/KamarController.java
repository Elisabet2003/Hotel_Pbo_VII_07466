package controller;

import entity.KamarEntity;
import model.KamarModel;

import java.util.ArrayList;

public class KamarController {
    public ArrayList<KamarEntity> getListKamar(){
        return KamarModel.getListKamar();
    }
    public int addKamar(String TipeKamar, String nomerKamar, int hargaKamar, int idKamar){
        KamarEntity kamar = new KamarEntity(TipeKamar, nomerKamar, hargaKamar, idKamar);
        int status = KamarModel.addKamar(kamar);
        return status;
    }

    public int getIndexKamar(int idKamar){
        return KamarModel.getIndexKamar(idKamar);
    }
    public int updateTipe(int idKamar, String tipeBaru){
        return KamarModel.updatTipe(idKamar, tipeBaru);
    }
    public int updateNomer(int idKamar, String nomerKamar){
        return KamarModel.updateNomer(idKamar, nomerKamar);
    }

    public int updateHarga(int idKamar, int harga){
        int status = KamarModel.updateHarga(idKamar, harga);
        return status;
    }
    public int removeKamar(int idTipeKamar){
        return KamarModel.removeKamar(idTipeKamar);
    }
}
