package controller;

import entity.ReservasiEntity;
import model.ReservasiModel;

import java.util.ArrayList;

public class ReservasiController {

    public ArrayList<ReservasiEntity> getListReservasi(){
        return ReservasiModel.getListReservasi();
    }
    public int addReservasi(String namaTamu, String nomerKamar){
        ReservasiEntity reservasi = new ReservasiEntity(namaTamu, nomerKamar);
        int status = ReservasiModel.addReservasi(reservasi);
        return status;
    }
}
