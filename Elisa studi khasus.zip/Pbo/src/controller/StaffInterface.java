package controller;

public interface StaffInterface {
    public void output();
}
