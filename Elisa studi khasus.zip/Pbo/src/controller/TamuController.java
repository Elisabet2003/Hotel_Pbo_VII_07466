package controller;

import entity.StaffEntity;
import entity.TamuEntity;
import model.StaffModel;
import model.TamuModel;

import java.util.ArrayList;

public class TamuController {
    public ArrayList<TamuEntity> getlistTamu(){
        return TamuModel.getTamuList();
    }
    public int addTamu(String namaTamu, String alamatTamu, boolean statusTamu, int idTamu){
        TamuEntity tamu = new TamuEntity(namaTamu, alamatTamu, idTamu, statusTamu);
        int status = TamuModel.addTamu(tamu);
        return status;
    }
    public int getIndexTamu(int idTamu){
        return TamuModel.getIndexTamu(idTamu);
    }
    public boolean cari(int idTamu,String passwordTamu){
        StaffEntity staff = StaffModel.cari(idTamu, passwordTamu);
        if (staff!=null){
            return true;
        }else{
            return false;
        }
    }
    public int updateNamaTamu(int idTamu, String namaTamu){
        return TamuModel.updateNamaTamu(idTamu, namaTamu);
    }
    public int updateAlamatTamu(int idTamu, String AlamatTamu){
        return TamuModel.updateAlamatTamu(idTamu, AlamatTamu);
    }
    public int updatStatus(int idTamu, boolean status){
        return TamuModel.updateStatus(idTamu,status);
    }
    public int removeTamu(int idTamu){
        return TamuModel.removeTamu(idTamu);
    }
}

