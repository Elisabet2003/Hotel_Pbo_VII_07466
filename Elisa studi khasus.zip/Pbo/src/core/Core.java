package core;
import entity.KamarEntity;
import entity.ReservasiEntity;
import entity.StaffEntity;
import entity.TamuEntity;

import java.util.ArrayList;

public class Core {
    public static ArrayList<KamarEntity> kamarEntityArrayList = new ArrayList<KamarEntity>();
    public static ArrayList<StaffEntity> staffEntityArrayList = new ArrayList<StaffEntity>();
    public static ArrayList<TamuEntity> tamuEntityArrayList = new ArrayList<TamuEntity>();
    public static ArrayList<ReservasiEntity> reservasiArrayList = new ArrayList<ReservasiEntity>();
}
