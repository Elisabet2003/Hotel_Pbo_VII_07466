package gui;// package gui;

// import controller.StaffController;
// import javax.swing.*;
// import java.awt.*;
// import java.awt.event.ActionEvent;
// import java.awt.event.ActionListener;

// public class LoginPage extends JFrame {

//     private StaffController staffController = new StaffController();
//     private JLabel mid;
//     private JTextField idLogin;
//     private JPasswordField passwordlogin;
//     private JLabel labelStaffLogin, labelPasswordLogin;
//     private JButton login;

//     public LoginPage() {
//         initWindow();
//         initComponent();
//     }
//     private void initWindow(){
//         setTitle("Studi Kasus");
//         setSize(500, 500);
//         setLayout(null);
//         getContentPane().setBackground(Color.CYAN);
//         setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//         setLocationRelativeTo(null);
//     }
//     private void initComponent(){
//         mid = new JLabel("LOGIN STAFF");
//         mid.setBounds(180, 80, 350, 50);
//         mid.setFont(new Font("Arial",Font.BOLD, 20));
//         add(mid);

//         labelStaffLogin = new JLabel("ID STAFF");
//         labelStaffLogin.setBounds(200, 183, 250, 30);
//         labelStaffLogin.setFont(new Font("Arial", Font.BOLD, 15));
//         add(labelStaffLogin);

//         idLogin = new JTextField();
//         idLogin.setBounds(105, 210, 280, 30);
//         add(idLogin);

//         labelPasswordLogin = new JLabel("PASSWORD");
//         labelPasswordLogin.setBounds(200, 250, 100, 30);
//         labelPasswordLogin.setFont(new Font("Arial", Font.BOLD, 15));
//         add(labelPasswordLogin);

//         passwordlogin = new JPasswordField();
//         passwordlogin.setBounds(105, 279, 280, 30);
//         add(passwordlogin);

//         login = new JButton("LOGIN");
//         login.setBounds(200, 350, 80, 30);
//         login.setBackground(Color.YELLOW);
//         add(login);


//         loginCheck();

//     }
//     private void loginCheck(){
//         login.addActionListener(new ActionListener() {
//             @Override
//             public void actionPerformed(ActionEvent e) {
//                 try {
//                     String idStaff = idLogin.getText();
//                     String password = passwordlogin.getText();

//                     if (staffController.cari(Integer.parseInt(idStaff), password)){
//                         JOptionPane.showMessageDialog(null,"Selamat Datang "+idStaff+" Di HOTEL MELATI!","information",JOptionPane.INFORMATION_MESSAGE);
//                         dispose();
//                         // new BukuGui().setVisible(true);
//                     }
//                     else{
//                         JOptionPane.showMessageDialog(null, "GAGAL LOGIN");
//                     }

//                 }catch (Exception exception){
//                     JOptionPane.showMessageDialog(null,"ID atau password salah","",JOptionPane.INFORMATION_MESSAGE);
//                     reset();
//                 }
//             }
//         });
//     }
//     void reset(){
//         idLogin.setText(null);
//         passwordlogin.setText(null);
//     }
// }
