package gui;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import controller.StaffController;
import entity.StaffEntity;

import java.awt.Color;
import java.awt.Font;

public class LoginStaff extends Frame{
    private JLabel perpusLabel,loginLabel,idLabel, passwordLabel;
    private JTextField idField;
    private JPasswordField passwordField;
    private JButton loginBtn;
    private JLabel imageLogin;

    public LoginStaff() {
        super("LOGIN", 400, 600);
        getContentPane().setBackground(Color.CYAN);
    }

    @Override
    protected void component() {
        imageLogin = new JLabel(loadImage("src/assets/Admin1.png", 200, 200));
        boundedAdd(imageLogin, 100, 62, 200, 200);

        perpusLabel = new JLabel("PERPUSTAKAAN");
        perpusLabel.setFont(new Font("Arial", Font.BOLD, 24));
        perpusLabel.setForeground(color("#2596be"));
        boundedAdd(perpusLabel, 100, 265, 200, 45);

        loginLabel = new JLabel("LOGIN ADMIN");
        loginLabel.setFont(new Font("Arial", Font.BOLD, 20));
        loginLabel.setHorizontalAlignment(SwingConstants.CENTER);
        boundedAdd(loginLabel, 95, 300, 200, 30);

        idLabel = new JLabel("ID STAFF");
        idLabel.setFont(new Font("Arial", Font.BOLD, 13));
        boundedAdd(idLabel, 65, 350, 100, 18);

        idField = new JTextField();
        boundedAdd(idField, 65, 370, 270, 30);

        passwordLabel = new JLabel("Password");
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 13));
        boundedAdd(passwordLabel, 65, 415, 65, 18);

        passwordField = new JPasswordField();
        boundedAdd(passwordField, 65, 435, 270, 30);

        loginBtn = new JButton("LOGIN");
        loginBtn.setForeground(Color.white);
        loginBtn.setBackground(color("#2596be"));
        loginBtn.setFocusPainted(false);
        boundedAdd(loginBtn, 157, 485, 85, 30);
    }

    @Override
    protected void event() {
        loginBtn.addActionListener((e) -> {
            try {
                int id = Integer.parseInt(idField.getText());
                String password = String.valueOf(passwordField.getPassword());
                StaffController staff = new StaffController();
                StaffEntity objekStaff = staff.cari(id, password);
                
                if(objekStaff!=null){
                    JOptionPane.showMessageDialog(null, "Hallo " + objekStaff.getNama(), "Login Sukses",
                            JOptionPane.INFORMATION_MESSAGE);
                            dispose();
                            new MenuGui().setVisible(true);
                }else{
                    JOptionPane.showMessageDialog(null, "Salah " , "Gagal Login",
                    JOptionPane.ERROR_MESSAGE);
                    dispose();
                    new LoginStaff().setVisible(true);
                }

            } catch (Exception er) {
                JOptionPane.showMessageDialog(null, "ID Harus Angka", "Login Gagal",
                            JOptionPane.ERROR_MESSAGE);
                            dispose();
                            new LoginStaff().setVisible(true);
            } 
        });
    }
}
