package gui;

import javax.swing.JButton;

import java.awt.Color;

public class MenuGui extends Frame{
    private JButton kamarButton,tamButton,reservasiButton,keluarBtn;

    public MenuGui() {
        super("MENU", 400, 600);
    }

    @Override
    protected void component() {

        kamarButton = new JButton("Kamar");
        kamarButton.setForeground(Color.white);
        kamarButton.setBackground(color("#2596be"));
        kamarButton.setFocusPainted(false);
        boundedAdd(kamarButton, 157, 250, 85, 30);

        tamButton = new JButton("Tamu");
        tamButton.setForeground(Color.white);
        tamButton.setBackground(color("#ff0000"));
        tamButton.setFocusPainted(false);
        boundedAdd(tamButton, 157, 300, 85, 30);

        reservasiButton = new JButton("Reservasi");
        reservasiButton.setForeground(Color.white);
        reservasiButton.setBackground(color("#2596be"));
        reservasiButton.setFocusPainted(false);
        boundedAdd(reservasiButton, 157, 350, 85, 30);

        keluarBtn = new JButton("Keluar");
        keluarBtn.setForeground(Color.white);
        keluarBtn.setBackground(color("#ff0000"));
        keluarBtn.setFocusPainted(false);
        boundedAdd(keluarBtn, 157, 400, 85, 30);
    }

    @Override
    protected void event() {
        kamarButton.addActionListener((e) -> {
            dispose();
            new KamarGui().setVisible(true);
        });

        tamButton.addActionListener((e)-> {

        });

        reservasiButton.addActionListener((e)->{

        });
        
        keluarBtn.addActionListener((e) -> {
            dispose();
            new LoginStaff().setVisible(true);
        });
    }
}
