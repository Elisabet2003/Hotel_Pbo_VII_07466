package gui;

public class MenuPage {
}
