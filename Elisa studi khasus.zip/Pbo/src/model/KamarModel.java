package model;
import java.util.*;

import core.Core;
import entity.KamarEntity;

public class KamarModel {
    private static ArrayList<KamarEntity> kamarEntityArrayList = Core.kamarEntityArrayList;
    public static ArrayList<KamarEntity> getListKamar(){
        return kamarEntityArrayList;
    }
    public static int addKamar(KamarEntity kamar){
        int status = -1;
        if (kamar == null){
            status = 0;
        }
        else {
            Core.kamarEntityArrayList.add(kamar);
            status = 1;
        }
        return status;
    }
    public static int updatTipe(int idKamar, String tipeBaru){
        int index = getIndexKamar(idKamar);
        Core.kamarEntityArrayList.get(index).setTipeKamar(tipeBaru);
        return index;
    }
    public static int updateNomer(int idKamar, String nomerBaru){
        int index = getIndexKamar(idKamar);
        Core.kamarEntityArrayList.get(index).setNomerKamar(nomerBaru);
        return index;
    }

    public static int updateHarga(int idKamar, int hargaKamar){
        int index = getIndexKamar(idKamar);
        Core.kamarEntityArrayList.get(index).setHargaKamar(hargaKamar);
        return index;
    }
    public static int getIndexKamar(int idKamar){

        int index = -1;
        if (kamarEntityArrayList.isEmpty()){
            System.err.println("DATA KOSONG");
            System.out.println("");
        }else{
            for (KamarEntity kamar : kamarEntityArrayList){
                if (kamar.getIdKamar()==idKamar){
                    index = kamarEntityArrayList.indexOf(kamar);
                }
            }
        }
        return  index;
    }
    public static int removeKamar(int idKamar){
        int index = getIndexKamar(idKamar);
        if (index !=-1){
            kamarEntityArrayList.remove(index);
        }
        return index;
    }
}
