package model;
import java.util.*;

import core.Core;
import entity.StaffEntity;

public class StaffModel {
    private static ArrayList<StaffEntity> staffEntityArrayList = Core.staffEntityArrayList;

    public static ArrayList<StaffEntity> getListStaff() {
        return staffEntityArrayList;
    }

    public static void initailStaff(){
        staffEntityArrayList.add(new StaffEntity("Elisa", "admin", 321));
    }

    public static int addStaff(StaffEntity staff) {
        int status = -1;
        if (staff == null) {
            status = 0;
        } else {
            Core.staffEntityArrayList.add(staff);
            status = 1;
        }
        return status;
    }

    public static StaffEntity cari(int id,String password){
        for (StaffEntity objek : staffEntityArrayList){
            if(objek.getIdStaff()==id && objek.getPassword().equals(password)){
                return objek;
            }
        }
        return null;
    }
    public static int updateNamaStaff(int idStaff, String namaStaff){
        int index = getIndexStaff(idStaff);
        Core.staffEntityArrayList.get(index).setNama(namaStaff);
        return index;
    }
    public static int updatePassStaff(int idStaff, String passStaff){
        int index = getIndexStaff(idStaff);
        Core.staffEntityArrayList.get(index).setPassword(passStaff);
        return index;
    }
    public static int getIndexStaff(int idStaff) {

        int index = -1;
        if (staffEntityArrayList.isEmpty()) {
            System.err.println("DATA KOSONG");
            System.out.println("");
        } else {
            for (StaffEntity staff : staffEntityArrayList) {
                if (staff.getIdStaff()==idStaff) {
                    index = staffEntityArrayList.indexOf(staff);
                }
            }
        }
        return index;
    }

    public static int removeStaff(int idStaff) {
        int index = getIndexStaff(idStaff);
        if (index != -1) {
            staffEntityArrayList.remove(index);
        }
        return index;
    }

}