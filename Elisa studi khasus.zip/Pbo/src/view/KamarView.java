package view;// package view;

// import controller.KamarController;
// import entity.KamarEntity;
// import entity.TamuEntity;
// import model.KamarModel;
// import java.util.*;
// import static core.Core.kamarEntityArrayList;


// public class KamarView {
//     KamarController kamarController = new KamarController();
//     public void kamarView(){
//     KamarModel kamarModel = new KamarModel();
//     Scanner keyboard = new Scanner(System.in);
//     int pilih;
//         System.out.println("1. Tambah Kamar");
//         System.out.println("2. Tampil Kamar");
//         System.out.println("3. Update Kamar");
//         System.out.println("4. Hapus Kamar");
//         System.out.println("5. EXIT");
//         System.out.print("Pilih : ");
//     pilih = keyboard.nextInt();
//         switch (pilih) {
//         case 1:
//             inputKamar();
//             break;
//         case 2:
//             viewKamar();
//             break;
//         case 3:
//             updateKamar();
//             break;
//         case 4:
//             hapusKamar();
//             break;
//         case 5:
//             System.out.println("EXIT");
//             break;
//         default:
//             System.out.println("Pilihan Tidak Ada");
//             break;
//         }
//     }

//     public void viewKamar(){
//         ArrayList<KamarEntity> kamarEntities = kamarController.getListKamar();
//         if (kamarEntities.isEmpty()){
//             System.err.println("DATA KOSONG");
//             System.out.println("");
//         }else {
//             for (KamarEntity kamar : kamarEntities) {
//                 System.out.println("Id Tipe Kamar : " + kamar.getTipeKamar());
//                 System.out.println("Nomer Kamar : " + kamar.getNomerKamar());
//                 System.out.println("Harga Kamar : " + kamar.getHargaKamar());
//                 System.out.println("Id Kamar : "+ kamar.getIdKamar());
//                 System.out.println("");
//             }
//         }
//     }

//     public void inputKamar(){
//         Scanner input = new Scanner(System.in);
//         System.out.print("Masukkan Tipe Kamar : ");
//         String idTipeKamar = input.nextLine();
//         System.out.print("Masukkan Nomer Kamar : ");
//         String nomerKamar = input.nextLine();
//         System.out.print("Masukkan Harga Kamar : ");
//         int hargaKamar = input.nextInt();
//         System.out.print("Masukkan Id Kamar : ");
//         int idKamar = input.nextInt();
//         int status = kamarController.addKamar(new KamarEntity(idTipeKamar, nomerKamar, hargaKamar, idKamar));
//         if (status == 0){
//             System.out.println("DATA GAGAL DIINPUTKAN");
//         }
//         else if (status == 1){
//             System.out.println("DATA BERHASIL DIINPUTKAN");
//         }
//         else {
//             System.out.println("INPUT ERROR");
//         }

//     }
//     public void updateKamar() {
//         ArrayList<KamarEntity> kamarEntities = kamarController.getListKamar();
//         Scanner input = new Scanner(System.in);
//         if (kamarEntities.isEmpty()) {
//             System.err.println("Data Tidak Ada");
//             System.out.println("");
//         } else {
//             System.out.print("Id Kamar : ");
//             int idKamar = input.nextInt();
//              int indeks =  kamarController.getIndexKamar(idKamar);
//             if (indeks != -1) {
//                 System.out.println("Mana yang Diupdate : ");
//                 System.out.println("1. Tipe Kamar : ");
//                 System.out.println("2. Nomer Kamar : ");
//                 System.out.println("2. Harga Kamar : ");
//                 System.out.print("Pilih : ");
//                 int pilih = input.nextInt();
//                 input.nextLine();
//                 switch (pilih) {
//                     case 1:
//                         System.out.print("Tipe Kamar Baru : ");
//                         String tipeKamar = input.nextLine();
//                         kamarController.updateNomer(idKamar,tipeKamar);
//                         break;
//                     case 2:
//                         System.out.print("Nomer Kamar Baru : ");
//                         String nomerKamar = input.nextLine();
//                         kamarController.updateNomer(idKamar, nomerKamar);
//                         break;
//                     case 3:
//                         System.out.print("Harga Kamar Baru : ");
//                         int hargaKamar= input.nextInt();
//                         kamarController.updateHarga(idKamar,hargaKamar);
//                         break;
//                 }
//             }else{
//                 System.out.println("TIDAK TERDAFTAR");
//             }
//         }
//     }
//     public void hapusKamar() {
//         ArrayList<KamarEntity> kamarEntities = kamarController.getListKamar();
//         Scanner input = new Scanner(System.in);
//         int kamar ;
//         if (kamarEntities.isEmpty()) {
//             System.out.println("Data Tidak Ada");
//             System.out.println("--------");
//         } else {
//             System.out.print("Id Kamar Yang Ingin Dihapus : ");
//             kamar = input.nextInt();
//             int indeks = kamarController.removeKamar(kamar);
//             if (indeks == -1){
//                 System.out.println("DATA YANG DIHAPUS TIDAK DITEMUKAN");
//             }
//             else {
//                 System.out.println("DATA INDEX - " + indeks + 1 + " TELAH DIHAPUS");
//             }
//         }
//     }
// }
