package view;// package view;

// import controller.StaffController;
// import entity.ReservasiEntity;
// import entity.StaffEntity;
// import model.ReservasiModel;

// import java.util.*;
// import static core.Core.staffEntityArrayList;
// import controller.ReservasiController;
// import java.util.Scanner;

// public class StaffView {
//     ReservasiModel reservasiModel = new ReservasiModel();
//     StaffController staffController =new StaffController();
//     ReservasiController reservasiController = new ReservasiController();
//     MainMenu main = new MainMenu();
//     Scanner input = new Scanner(System.in);

//     public  static void initial(){
//         staffEntityArrayList.add(new StaffEntity("Elisa","admin",321));

//     }

//     public void menu_staff() {
//         int pilih;

//         do {
//             System.out.println("Menu Staff");
//             System.out.println("1. Login");
//             System.out.println("2. Exit");
//             System.out.print("Pilih : ");
//             pilih = input.nextInt();

//             switch(pilih) {
//                 case 1 :
//                     login();
//                     break;
//             }
//         } while(pilih != 2);
//     }

//     public void login(){
//         Scanner input = new Scanner(System.in);
//         try{
//             System.out.print("Masukkan Id       = ");
//             int id = input.nextInt();
//             input.nextLine();
//             System.out.print("Masukkan Password = ");
//             String pass = input.nextLine();
//             boolean status = staffController.cari(id,pass);
//             if(status){
//                 main.menu();
//             }else {
//                 System.out.println("Tidak Valid");
//             }
//         }catch (Exception e){
//             System.out.println("Id Harus Angka");
//             input.nextLine();
//         }
//     }
//     public void staffView(){
//         Scanner keyboard = new Scanner(System.in);
//         int pilih;
//             System.out.println("1. Nama Tamu");
//             System.out.println("2. Lihat Reservasi ");
// //            System.out.println("3. Update Staff");
// //            System.out.println("4. Hapus Staff");
//             System.out.println("3. exit");
//             System.out.print("Pilih : ");
//             pilih = keyboard.nextInt();
//             switch (pilih) {
//                 case 1:
//                     addReservasi();
//                     break;
// //                case 2:
// //                    viewStaff();
// //                    break;
//                 case 2:
//                     viewReservasi();
//                     break;
//                 case 3 :
//                     System.out.println("EXIT");
//                     break;
//                 default:
//                     System.out.println("Pilihan Tidak Ada");
//                     break;
//             }
//         }
// //    public void viewStaff(){
// //        ArrayList<StaffEntity> staffEntities = staffController.getListStaff();
// //        if (staffEntities.isEmpty()){
// //            System.err.println("DATA KOSONG");
// //            System.out.println("");
// //        }else {
// //            for (StaffEntity staff : staffEntities) {
// //                System.out.println("Nama Staff : " + staff.getNama());
// //                System.out.println("Id Staff : " + staff.getIdStaff());
// //                System.out.println("Password Staff : "+ staff.getPassword());
// //                System.out.println("");
// //            }
// //        }
// //    }

//     public void viewReservasi(){
//         ArrayList<ReservasiEntity> reservasiEntities= reservasiController.getListReservasi();
//         if (reservasiEntities.isEmpty()){
//             System.err.println("DATA KOSONG");
//             System.out.println("");
//         }else {
//             for (ReservasiEntity reservasi : reservasiEntities) {
//                 System.out.println("Nama Tamu : " + reservasi.getNamaTamu());
//                 System.out.println("Nomer Kamar : " + reservasi.getNomerKamar());
//                 System.out.println("");
//             }
//         }
//     }
//     public void addReservasi(){
//         {
//             Scanner input = new Scanner(System.in);
//             System.out.print("Masukkan Nama Tamu : ");
//             String namaTamu = input.nextLine();
//             System.out.print("Masukkan Nomer Kamar: ");
//             String nomerKamar = input.nextLine();
//             int status = reservasiController.addReservasi(new ReservasiEntity(namaTamu,nomerKamar));
//             if (status == 0){
//                 System.out.println("DATA GAGAL DIINPUTKAN");
//             }
//             else if (status == 1){
//                 System.out.println("DATA BERHASIL DIINPUTKAN");
//             }
//             else {
//                 System.out.println("INPUT ERROR");
//             }

//         }
//     }
// }





